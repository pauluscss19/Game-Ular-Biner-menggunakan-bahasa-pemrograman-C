#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windows.h>

// Deklarasi variabel global
int i, j, lapangan[15][50], x = 10, y = 20, ekor = 1, bx, by, score = 0;
char pilihan = 'd';

// Fungsi untuk memindahkan kursor ke posisi tertentu
void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = y;
    coord.Y = x;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

// Fungsi random untuk membuat buah
void buat_buah()
{
    srand(time(NULL));
    bx = rand() % 13 + 1;
    by = rand() % 48 + 1;
    lapangan[bx][by] = -1;
}

// Fungsi untuk menampilkan lapangan atau kotak area permainan
void tampilkan()
{
    gotoxy(0, 0); // Memindahkan kursor ke posisi awal
    printf("\033[1;32m"); // Mengubah warna output menjadi hijau
    for (i = 0; i < 15; i++)
    {
        for (j = 0; j < 50; j++)
        {
            if (i == 0 || i == 14 || j == 0 || j == 49)
                lapangan[i][j] = 8;
            if (lapangan[i][j] == 8)
                printf("|");
            else if (lapangan[i][j] == -1)
                printf("1");
            else if (lapangan[i][j] > 0 && lapangan[i][j] != 8)
                printf("O");
            else if (lapangan[i][j] == 0)
                printf(" ");
        }
        printf("\n");
    }
    printf("\033[1;32m"); // Mengubah warna output menjadi hijau

    // Menampilkan skor di bawah area permainan
    printf("Score: %d\n", score);

    // Menampilkan kontrol di sebelah kanan area permainan
    printf("\nKontrol:\n");
    printf("W: untuk ke atas\n");
    printf("A: untuk ke kiri\n");
    printf("S: untuk ke bawah\n");
    printf("D: untuk ke kanan\n");
    printf("X: untuk mengakhiri game\n");
    printf("\n----------------------------------------\n");
    printf("Nama Kelompok : \n");
	printf("1. Paulus Calep Sandria Saputra	(23081010275)\n");
	printf("2. Nathanael Kristian Sujarwo	(23081010271)\n");
}

// Fungsi untuk menggerakkan ular
void gerak()
{
    if (kbhit())
    {
        pilihan = getch();
    }
    if (pilihan == 'w')
        x--;
    if (pilihan == 's')
        x++;
    if (pilihan == 'a')
        y--;
    if (pilihan == 'd')
        y++;

    // Pengecekan batas lapangan
    if (x < 1) x = 13;
    if (x > 13) x = 1;
    if (y < 1) y = 48;
    if (y > 48) y = 1;

    // Jika ular menabrak dirinya sendiri
    if (lapangan[x][y] > 0)
    {
        printf("Game Over! Ular menabrak dirinya sendiri.\n");
        exit(0);
    }

    // Jika huruf 'X' ditekan
    if (pilihan == 'x' || pilihan == 'X')
    {
        printf("Game Over! Anda menekan 'X'.\n");
        exit(0);
    }

    if (lapangan[x][y] == -1)
    {
        ekor++;
        score += 10; // Tambah skor setiap kali buah dimakan
        buat_buah();
    }
    for (i = 0; i < 15; i++)
    {
        for (j = 0; j < 50; j++)
        {
            if (lapangan[i][j] > 0)
                lapangan[i][j]--;
        }
    }
    lapangan[x][y] = ekor;
}

// Fungsi utama
int main()
{
    buat_buah();
    int speed = 50; // Kecepatan ular dalam milidetik
    while (1)
    {
        tampilkan();
        gerak();
        Sleep(speed); // Memberi delay dengan fungsi Sleep
    }
    return 0;
}